const RARITIES = {
  common: { name: 'Обычная', color: '#94a3b8', price: 10 },
  uncommon: { name: 'Необычная', color: '#22c55e', price: 25 },
  rare: { name: 'Редкая', color: '#38bdf8', price: 75 },
  epic: { name: 'Эпическая', color: '#a855f7', price: 200 },
  legendary: { name: 'Легендарная', color: '#f59e0b', price: 750 },
  mythic: { name: 'Мифическая', color: '#ef4444', price: 2500 }
};

const CASES = [
  { id:'lviv', name:'Lviv', subtitle:'ПЕРСОНАЖИ', color:'#22d3ee', cooldownHours:5, xp:100, description:'Только персонажи CHAK338 — от обычных до мифических.', emoji:'🧑‍🚀' },
  { id:'kiyv', name:'Kiyv', subtitle:'ОДЕЖДА', color:'#c946f2', cooldownHours:12, xp:150, description:'Одежда, маски, куртки и редкие образы.', emoji:'🧥' },
  { id:'vinnitsia', name:'Vinnytsia', subtitle:'DOTA 2', color:'#ff4747', cooldownHours:24, xp:250, description:'Только предметы из мира Dota 2.', emoji:'⚔️' }
];

// Для проекта предусмотрен встроенный SVG-fallback, поэтому предметы остаются видимыми
// даже если папка assets ещё не загружена на GitHub Pages.
function svgImage(label, emoji, color){
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 300"><defs><radialGradient id="g"><stop stop-color="${color}" stop-opacity=".45"/><stop offset="1" stop-color="#08080d" stop-opacity="0"/></radialGradient></defs><rect width="420" height="300" rx="28" fill="#0b0b12"/><rect x="12" y="12" width="396" height="276" rx="22" fill="url(#g)" stroke="${color}" stroke-opacity=".35"/><text x="210" y="155" text-anchor="middle" font-size="78">${emoji}</text><text x="210" y="238" text-anchor="middle" fill="white" font-family="Arial,sans-serif" font-size="28" font-weight="800">${label}</text></svg>`;
  return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

const ITEMS = [
  { id:'lviv_rookie', caseId:'lviv', name:'Rookie', emoji:'🧑', rarity:'common', price:10, chance:55, type:'character', image:svgImage('ROOKIE','🧑','#94a3b8') },
  { id:'lviv_masky', caseId:'lviv', name:'Masky', emoji:'😎', rarity:'uncommon', price:25, chance:25, type:'character', image:svgImage('MASKY','😎','#22c55e') },
  { id:'lviv_cyber', caseId:'lviv', name:'Cyber', emoji:'🤖', rarity:'rare', price:75, chance:12, type:'character', image:svgImage('CYBER','🤖','#38bdf8') },
  { id:'lviv_shadow', caseId:'lviv', name:'Shadow', emoji:'🥷', rarity:'epic', price:200, chance:6, type:'character', image:svgImage('SHADOW','🥷','#a855f7') },
  { id:'lviv_glitch', caseId:'lviv', name:'Glitch', emoji:'👾', rarity:'legendary', price:750, chance:1.8, type:'character', image:svgImage('GLITCH','👾','#f59e0b') },
  { id:'lviv_uhilyant', caseId:'lviv', name:'Uhilyant', emoji:'👹', rarity:'mythic', price:2500, chance:.2, type:'character', image:svgImage('UHILYANT','👹','#ef4444') },

  { id:'kiyv_tshirt', caseId:'kiyv', name:'Basic T-Shirt', emoji:'👕', rarity:'common', price:10, chance:55, type:'outfit', image:svgImage('T-SHIRT','👕','#94a3b8') },
  { id:'kiyv_hoodie', caseId:'kiyv', name:'CHAK Hoodie', emoji:'🧥', rarity:'uncommon', price:25, chance:25, type:'outfit', image:svgImage('CHAK HOODIE','🧥','#22c55e') },
  { id:'kiyv_jacket', caseId:'kiyv', name:'Neon Jacket', emoji:'🥼', rarity:'rare', price:75, chance:12, type:'outfit', image:svgImage('NEON JACKET','🥼','#38bdf8') },
  { id:'kiyv_mask', caseId:'kiyv', name:'Dark Mask', emoji:'🎭', rarity:'epic', price:200, chance:6, type:'outfit', image:svgImage('DARK MASK','🎭','#a855f7') },
  { id:'kiyv_crown', caseId:'kiyv', name:'Golden Crown', emoji:'👑', rarity:'legendary', price:750, chance:1.8, type:'outfit', image:svgImage('GOLDEN CROWN','👑','#f59e0b') },
  { id:'kiyv_338', caseId:'kiyv', name:'338 Outfit', emoji:'🕶️', rarity:'mythic', price:2500, chance:.2, type:'outfit', image:svgImage('338 OUTFIT','🕶️','#ef4444') },

  { id:'dota_tango', caseId:'vinnitsia', name:'Tango', emoji:'🌿', rarity:'common', price:10, chance:55, type:'dota', image:svgImage('TANGO','🌿','#94a3b8') },
  { id:'dota_branches', caseId:'vinnitsia', name:'Iron Branch', emoji:'🌱', rarity:'uncommon', price:25, chance:25, type:'dota', image:svgImage('IRON BRANCH','🌱','#22c55e') },
  { id:'dota_blink', caseId:'vinnitsia', name:'Blink Dagger', emoji:'🗡️', rarity:'rare', price:12, type:'dota', image:svgImage('BLINK DAGGER','🗡️','#38bdf8') },
  { id:'dota_bkb', caseId:'vinnitsia', name:'Black King Bar', emoji:'👑', rarity:'epic', price:200, chance:6, type:'dota', image:svgImage('BLACK KING BAR','👑','#a855f7') },
  { id:'dota_aghanim', caseId:'vinnitsia', name:"Aghanim's Scepter", emoji:'💎', rarity:'legendary', price:750, chance:1.8, type:'dota', image:svgImage("AGHANIM'S",'💎','#f59e0b') },
  { id:'dota_rapier', caseId:'vinnitsia', name:'Divine Rapier', emoji:'⚔️', rarity:'mythic', price:2500, chance:.2, type:'dota', image:svgImage('DIVINE RAPIER','⚔️','#ef4444') }
];
// Исправляем стоимость Blink Dagger согласно таблице редкостей.
ITEMS.find(i=>i.id==='dota_blink').price = 75;
ITEMS.find(i=>i.id==='dota_blink').chance = 12;

function getCase(id){ return CASES.find(c=>c.id===id); }
function getItem(id){ return ITEMS.find(i=>i.id===id); }
function getCaseItems(caseId){ return ITEMS.filter(i=>i.caseId===caseId); }
function formatPrice(value){ return `${Number(value||0).toLocaleString('ru-RU')} коп.`; }
function getInventory(){ try{return JSON.parse(localStorage.getItem('chak338_inventory')||'[]');}catch{return [];} }
function saveInventory(items){ localStorage.setItem('chak338_inventory',JSON.stringify(items)); }
function addInventoryItem(item){ const inv=getInventory(); inv.push({...item,droppedAt:Date.now(),uid:`${item.id}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`}); saveInventory(inv); }
function removeInventoryItems(uids){ const set=new Set(uids); saveInventory(getInventory().filter(i=>!set.has(i.uid))); }
function getXP(){ return Number(localStorage.getItem('chak338_xp')||0); }
function addXP(value){ const xp=getXP()+Number(value||0); localStorage.setItem('chak338_xp',String(xp)); return xp; }
function getLevel(){ return Math.floor(getXP()/1000)+1; }
function cooldownKey(caseId){ return `chak338_case_${caseId}`; }
function getRemaining(caseId){ const c=getCase(caseId); const last=Number(localStorage.getItem(cooldownKey(caseId))||0); if(!last)return 0; return Math.max(0,c.cooldownHours*3600000-(Date.now()-last)); }
function getNextOpenTime(caseId){ const last=Number(localStorage.getItem(cooldownKey(caseId))||0); return last ? new Date(last+getCase(caseId).cooldownHours*3600000) : new Date(); }
function canOpenCase(caseId){ return getRemaining(caseId)<=0; }
function setCaseOpened(caseId){ localStorage.setItem(cooldownKey(caseId),String(Date.now())); }
function randomCaseItem(caseId){ const items=getCaseItems(caseId); let roll=Math.random()*100,cursor=0; for(const item of items){cursor+=Number(item.chance||0);if(roll<=cursor)return item;} return items[items.length-1]; }
function rarityClass(rarity){ return `rarity-${rarity}`; }
